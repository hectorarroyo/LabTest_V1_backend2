<?php

class Person
{
	public $Name;
}

?>
